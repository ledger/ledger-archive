/* MWApplication */

#import <Cocoa/Cocoa.h>

@interface MWApplication : NSApplication
{
    IBOutlet id aboutPanel;
}
@property (retain) id aboutPanel;
@end
