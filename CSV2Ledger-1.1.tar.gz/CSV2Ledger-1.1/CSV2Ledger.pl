#!/usr/bin/perl

######################################################################
# CSV2Ledger.pl
#
# This script reads a CSV file and outputs it in Ledger format. It is
# useful for converting data from financial institutions into your
# Ledger.
#
# Optional processing matches records by regexp and can perform
# substitutions, as well as choose a source and destination account
# for that record. This can automatically rename vendors, and assign
# records to specific accounts.
#
# Written by: Russell Adams <rladams@adamsinfoserv.com>
# License: GPLv2
#
#
# Ledger entry model
#
# CSV from bank:
#
# 2008/08/08,2134,Exxon,20
# 
# %Transaction = (
#     'Date' = '2008/08/08'                # CSV
#     , 'Cleared' = ''                     # Default
#     , 'CheckNum' = '2134'                # CSV
#     , 'Desc' = 'Exxon'                   # CSV
#     , 'Source' = 'Liabilities:VISA'      # Via Lookup
#     , 'Dest' = 'Expenses:Auto:Gas'       # Via Lookup
#     , 'Amount' = 20                      # CSV
#     , 'Comments' = ( 'MD5Sum: .......'   # Generated
#                      , 'Original: CSV' ) # Generated
#     );
#
# becomes
#
# ; MD5Sum: .......
# ; Original: CSV
# 2008/08/08 (2134) Exxon
#  Liabilities:VISA         $20.00
#   Expenses:Auto:Gas
#
##################################################

# Always
use strict;
use warnings;

# Modules
use YAML;            # Dispatch Table Loading
use Getopt::Long;    # Options processing

use Date::Format;    # Date conversion
use Date::Parse;

use Digest::MD5 qw/ md5_hex/;  # Help detect duplicates later

use Text::CSV;       # Required for import

# Globals
my $CSV = Text::CSV->new( );

my @Data;

##################################################
# Defaults
#
# Different CSV files use different fields.
# These are the defaults from my financial
# institution, and can be specified via arguments.

# RecordRE is used to match lines to import, and exclude any comments or junk
# Mine all start with the date
my $RecordRE = "^[0-9][0-9]\/[0-9][0-9]\/";

# CSV field layout, a comma delimited list of fields being read from each line
# This is used to match position to label
my $CSVFields = "Posted Date,Check Number,Description,Transaction Amount,Principal Amount,Interest Amount,Balance,Fee Amount";

# Which field name is our date?
my $DateField = "Posted Date";

# Which field is a check number?
my $CheckField = "Check Number";

# Which field is the description?
my $DescField = "Description";

# Which field is the amount?
my $AmountField = "Transaction Amount";

# What default source account?
my $DefaultSource = "Assets:Unknown";

# No file by default
my $PreProcessFile;
my $AccountMatchFile;

# Other
my $Cleared;
my $DetectDups;
my $ShowHelp;
my $InputFile;
my $OutputFile;

# End defaults
##################################################

##################################################
# Options processing

GetOptions(   'r=s' => \$RecordRE
			, 'c=s' => \$CSVFields
			, 'd=s' => \$DateField
			, 'n=s' => \$CheckField
			, 't=s' => \$DescField
			, 'a=s' => \$AmountField
			, 's=s' => \$DefaultSource
			, 'x'   => \$Cleared
            , 'z'   => \$DetectDups
			, 'p=s' => \$PreProcessFile
			, 'm=s' => \$AccountMatchFile
			, 'i=s' => \$InputFile
			, 'o=s' => \$OutputFile
			, 'h|help' => \$ShowHelp
	) || die 'Failed to get options';

$Cleared = defined $Cleared ? "*" : "";

defined $InputFile || die "Specify an input file";
defined $OutputFile || die "Specify an output file";

( -f $InputFile ) || die "Specify an existing file";

defined $ShowHelp && do {
	print <<EOF;
Usage: CSV2Ledger [OPTION] -i FILE -o FILE
Converts CSV entries to Ledger format.

Options:
 -i <file>                Input filename
 -o <file>                Output filename
 -r "regexp"              Record matching RE
 -c "label,label,<...>"   Field label list
 -d "label"               Date field label
 -n "label"               Check Number field label
 -t "label"               Description field label
 -a "label"               Amount field label
 -x                       Mark transactions cleared
 -z                       Turn on duplicate detection (SLOW)
 -s "Account"             Default Source Account
 -p <file>                Preprocess table YAML file
 -m <file>                Account matching table YAML file

EOF
	exit;
	};   
	 


######################################################################
# Table of dynamic preprocessing
#
# Each match will be compared against the transaction prior to being
# split. The the match works, then the substitution will execute.
#

my @PreProcessReTable = (); # Now imported via YAML

sub PreProcess {

	my ( $orig ) = @_;

	for my $CurRe ( @PreProcessReTable ) {
			
		# If we match
		eval "\$orig =~ $CurRe->[0]" &&
			
			# Apply the substition
			eval "\$orig =~ $CurRe->[1]";
		
	};
	
	return $orig;

};

#	
##################################################

######################################################################
# Table of dynamic preprocessing
#
# Each match will be compared against the transaction prior to being
# split. The the match works, then the accounts are returned.
#

my @AccountMatchTable = (); # Now imported via YAML

sub AccountMatch {

	my ( $orig ) = @_;

	for my $CurRe ( @AccountMatchTable ) {
			
		# If we match
		eval "\$orig =~ $CurRe->[0]" &&

			# Return first match
			return { 'Source' => $CurRe->[1]
						 , 'Dest' => $CurRe->[2]
						 };
	};

	return { 'Source' => $DefaultSource
				 , 'Dest' => 'Expense:Unknown'
	};
	
};

#	
##################################################


##############################
# MAIN

# Parse the field names into the field array
my @Fields = split(/,/,$CSVFields);

# Load PreProcess dispatch table
defined $PreProcessFile && do {

	@PreProcessReTable = YAML::LoadFile($PreProcessFile);

};

# Load AccountMatch dispatch table
defined $AccountMatchFile && do {

	@AccountMatchTable = YAML::LoadFile($AccountMatchFile);
	
};

# Open input/output
open(FH, $InputFile) || die "Failed to open $InputFile";

# Don't open output here if we're looking for dups
defined $DetectDups || do {
		open(OUT, ">>" . "$OutputFile" )
			|| die "Failed to open $OutputFile for writing";
};

# Main loop, one line at a time from our input CSV
while ( <FH> ) {

	my %Transaction;

	chomp;

	# Only process records matching the RecordRE
	# This skips comments and cruft
	/$RecordRE/ || next;

	# Keep the original for ledger comments
	my $OrigCSV = $_;
	
	# Run the preprocessor, don't assume $_
	$_=&PreProcess( $_ );
	
	# Use the CSV module to pull in the input line
	my $Status = $CSV->parse($_);
	my @Columns = $CSV->fields();

	# Check column count
	die "Field count did not match" if ( $#Columns ne $#Fields );

	# Fast way to put the columns into the hash by field
	# both arrays must match by position
	@Transaction{ @Fields } = @Columns;

	# Create transaction
	# Includes date processing, Date::Parse is pretty intelligent
	# so I don't have to give it an input format string
	my $TempTrans = {
		'Date'       => time2str("%Y/%m/%d",str2time($Transaction{$DateField}))
		, 'Cleared'  => $Cleared
		, 'CheckNum' => $Transaction{$CheckField}
		, 'Desc'     => $Transaction{$DescField}
		, 'Amount'   => $Transaction{$AmountField}
		, 'Comments' => [ 'MD5Sum: ' . md5_hex($OrigCSV)  # later dup detect
						 , 'CSV: ' . $OrigCSV ]           # reference
		};

	# Match our source / dest accounts
	$TempTrans = { %{$TempTrans}, %{&AccountMatch($_)} };

	# Set to default if undefined
	$TempTrans->{'Source'} //= $DefaultSource;

	# Set to default if empty
	if ( $TempTrans->{'Source'} eq '' ) {
		$TempTrans->{'Source'} = $DefaultSource; };

	#########################################################
	# Duplicate Detection
	#
	# Yes, I'm reopening and scanning the file each time.
	# Its terribly inefficient, and a real hack.
	# If your ledger file is long enough this is causing a
	# problem, consider archiving. ;]

	defined $DetectDups && do {

		# If the output file doesn't exist, don't sweat it
		( -f $OutputFile ) && do {

			# Open output file
			open(DUP, "<" . "$OutputFile" )
				|| die "Failed to open $OutputFile for reading";
			
			# Grep the output file for the MD5 sum, skip if present.
			if ( grep(/$TempTrans->{'Comments'}[0]/,<DUP>) ) {
				close DUP;
				print STDERR "Skipping $TempTrans->{'Comments'}[0]\n";
				next;
			};
			
			close DUP;

		};
		
	};
	

	########################################
	# Output

    # Open output here if we're looking for dups
	defined $DetectDups && do {
		open(OUT, ">>" . "$OutputFile" )
			|| die "Failed to open $OutputFile for writing";
	};

	# Comments first
	foreach ( @{$TempTrans->{'Comments'}} ) { printf(OUT "; %s\n",$_); };

	# Record
	printf(OUT "%s %s (%s) %s\n"  # Entry
		   ,$TempTrans->{'Date'}
		   ,$TempTrans->{'Cleared'}
		   ,$TempTrans->{'CheckNum'}
		   ,$TempTrans->{'Desc'}
		);
	
	printf(OUT "\t%s\t%30.2f\n" # First split w/ amount
		   ,$TempTrans->{'Source'}
		   ,$TempTrans->{'Amount'}
		);
	
	printf(OUT "\t%s\t\n\n"   # Second split 
		   ,$TempTrans->{'Dest'}
		);

	# Close between writes
	defined $DetectDups && close OUT;

}

# If we're not detecting dups, close output
defined $DetectDups || close OUT;
close FH;

# END
##################################################
